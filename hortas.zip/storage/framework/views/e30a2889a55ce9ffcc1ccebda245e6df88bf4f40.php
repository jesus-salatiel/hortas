<?php $__env->startSection('style_card'); ?>
<style>
.caixa-horta {
        display: flex;
        flex-wrap: wrap;
        padding: 11px;
        gap: 11px;
        justify-content: center;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Downloads'); ?>

<?php $__env->startSection('content'); ?>




<section class="section">

    <h1>DOWNLOADS</h1>

    <div class="card caixa-horta" style="width: 100%; height: 100%;">

        <?php $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card" style="width: 210px; height: 310px; min-width:110px">

                <div class="card-image waves-effect waves-block waves-light ">
                    <img src="<?php echo e($download->foto); ?>">
                </div>
                <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4"><i
                            class="material-icons right">more_vert</i></span>
                    <span style="font-size:110%"><strong>Conteúdo</strong></span> <br>
                    <p class="truncate"><?php echo e($download->descricao); ?></p>
                    <a href="<?php echo e($download->url); ?>">DOWNLOAD</a>
                </div>

                <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Informações<i
                        class="material-icons right">close</i></span>
                    <p style="text-align: justify"><?php echo e($download->descricao); ?></p>

                </div>
            </div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main_site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetos\hortas\resources\views/downloads.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    

    
    <link rel="stylesheet" href="<?php echo e(asset('css/fotos.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.css')); ?>">

    <?php echo $__env->yieldContent('style_card'); ?>

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

    
    <nav style="background-color: #0d6efd;">
        <div class="container">
            <div class="nav-wrapper ">
                <!-- Voltar pagina anterior -->
                <a  href="<?php echo e(url()->previous()); ?>">
                    <span>Voltar</span>
                </a>


                


                <ul class="right">
                    <li>
                        <a href="<?php echo e(route('info')); ?>" >Hortaliças</a>
                    </li>
                    <li>
                        
                    </li>
                    <li class="relative flex items-top justify-center  sm:items-center py-4 sm:pt-0">
                        <?php if(Route::has('login')): ?>
                            
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(route('admin.hortas.index')); ?>" class="text-sm underline">Administrativo</a>
                                    <li>
                                    <?php if(auth()->id()): ?>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                                        <?php echo csrf_field(); ?>

                                            <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                        this.closest('form').submit(); " role="button">

                                                <?php echo e(__('Sair')); ?>

                                            </a>

                                    </form>
                                <?php else: ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('login')); ?>"  role="button">
                                            <i class="fas fa-sign-in-alt"></i>
                                            Login
                                        </a>
                                    </li>
                                <?php endif; ?>
                                    </li>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="text-sm  underline">Entrar</a>

                                    

                                <?php endif; ?>
                            </li>
                        <?php endif; ?>

                    </li>

                </ul>

            </div>

        </div>

    </nav>


    
    <div class="container">

        <?php echo $__env->yieldContent('content'); ?>

    </div>


<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>



    <script>

        <?php if(session('sucesso')): ?>
            M.toast({html:"<?php echo e(session('sucesso')); ?>"});
        <?php endif; ?>

        document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('select');
        var instances = M.FormSelect.init(elems);

        //MATERIAL BOX
        var boxes = document.querySelectorAll('.materialboxed');
        M.Materialbox.init(boxes);

        });

        // Navbar
        const elemsDropdown = document.querySelectorAll(".dropdown-trigger");
        const instancesDropdown = M.Dropdown.init(elemsDropdown, {
            coverTrigger: false
        });
        const elemsSidenav = document.querySelectorAll(".sidenav");
        const instancesSidenav = M.Sidenav.init(elemsSidenav, {
            edge: "left"
        });

        // //MODAL
        // var elems = document.querySelectorAll('.modal');
        // var instances = M.Modal.init(elems, options);
        // });


        // $(document).ready(function(){
        // $('select').formSelect();
        // });


    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\projetos\hortas\resources\views/layouts/main_site.blade.php ENDPATH**/ ?>
<?php $__env->startSection('style_card'); ?>
<style>
.caixa-horta {
        display: flex;
        flex-wrap: wrap;
        padding: 11px;
        gap: 11px;
        justify-content: center;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Horta Educativa'); ?>

<?php $__env->startSection('content'); ?>



<section class="section">


    <div class="card caixa-horta" style="width: 100%; height: 100%;">

        <?php $__currentLoopData = $hortas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

            

            <div class="card" style="width: 300px; height: 370px; min-width:150px">

                <div class="card-image waves-effect waves-block waves-light ">
                    <img src="storage/<?php echo e($horta->fotos[0]->url); ?>">
                </div>
                <div class="card-content">
                    <span class="card-title activator grey-text text-darken-4"><i
                            class="material-icons right">more_vert</i></span>
                    <span style="font-size:110%"><strong> INFORMAÇÕES</strong></span> <br><br>
                    <div style="font-size:110%; font-weight: bold;"> Horta da Escola: </div>
                    <div style="font-size:130%"><?php echo e($horta->escola['nome']); ?></div>
                    <div>
                        <a href="<?php echo e(route('galeria.show', [$horta->id])); ?>">Galeria de Fotos</a>
                    </div>
                </div>

                <div class="card-reveal">
                    <span class="card-title grey-text text-darken-4">Informações<i
                            class="material-icons right">close</i></span>
                    <p style="text-align: justify"><?php echo e($horta->descricao); ?></p>
                    <a href="http://"></a>
                </div>
            </div>

            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</section>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main_site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetos\hortas\resources\views/galeria/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Hortas'); ?>

<?php $__env->startSection('content'); ?>

    <section class="section">

        <table class="highlight">
            <thead>
                <tr>
                    <th>Escola</th>

                    <th>Título</th>
                    <th class="right-align">Opções</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $hortas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($horta->escola->nome); ?></td>

                        <td><?php echo e($horta->nome_horta); ?></td>
                        <td class="right-align">
                            
                            <a href="<?php echo e(route('admin.hortas.fotos.index', $horta->id)); ?>">
                                <span>
                                    <i class="material-icons green-text text-light-2">insert_photo</i>
                                </span>
                            </a>
                            

                            

                            
                            <a href="<?php echo e(route('admin.hortas.edit', $horta->id)); ?>">
                                <span>
                                    <i class="material-icons blue-text text-accent-2">edit</i>
                                </span>
                            </a>
                            
                            <form action="<?php echo e(route('admin.hortas.destroy', $horta->id)); ?>" method="post" style="display: inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button style="border:0;background:transparent" type="submit">
                                    <span style="cursor: pointer">
                                        <i class="material-icons red-text text-accent-3">delete_forever</i>
                                    </span>
                                </button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4"> Não existe Cadastro</td>
                    </tr>
                <?php endif; ?>
            </tbody>

        </table>

        <div class="fixed-action-btn">
            <a class="btm-floating btn-large waves-effect #1565c0 blue darken-2  btn" href="<?php echo e(route('admin.hortas.create')); ?>">
                <i class="large material-icons">add</i>
            </a>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetos\hortas\resources\views/admin/hortas/index.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/fotos.css')); ?>">

    <?php echo $__env->yieldContent('style_card'); ?>

    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

    
    <nav style="background-color: #0d6efd">
        <div class="container">
            <div class="nav-wrapper ">
                <a  href="<?php echo e(url()->previous()); ?>">Voltar
                </a>
                
                <ul class="right">
                    <li>
                        <a href="<?php echo e(route('admin.hortas.index')); ?>" >Hortas</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('welcome')); ?>" >Página Inicial</a>
                    </li>
                    <li>
                    <?php if(auth()->id()): ?>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                                <a class="nav-link " href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                            this.closest('form').submit(); " role="button">

                                    <?php echo e(__('Sair')); ?>

                                </a>

                        </form>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link " href="<?php echo e(route('login')); ?>" role="button">
                                <i class="fas fa-sign-in-alt"></i>
                                Login
                            </a>
                        </li>
                    <?php endif; ?>
                    </li>

                    

                </ul>

            </div>

        </div>

    </nav>

    
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>


<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>



    <script>

        <?php if(session('sucesso')): ?>
            M.toast({html:"<?php echo e(session('sucesso')); ?>"});
        <?php endif; ?>

        document.addEventListener('DOMContentLoaded', function() {
        var elems = document.querySelectorAll('select');
        var instances = M.FormSelect.init(elems);
        });

        // $(document).ready(function(){
        // $('select').formSelect();
        // });

    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\projetos\hortas\resources\views/admin/layouts/main.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', __('Não encontrado')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', "Página não encontrada"); ?>

<?php echo $__env->make('errors::illustrated-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projetos\hortas\resources\views/errors/404.blade.php ENDPATH**/ ?>
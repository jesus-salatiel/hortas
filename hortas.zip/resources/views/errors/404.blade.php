@extends('errors::illustrated-layout')

@section('title', __('Não encontrado'))
@section('code', '404')
@section('message', "Página não encontrada")
